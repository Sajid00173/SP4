```markdown
# Computer Science Engineering Fundamentals Quiz

---
1. What is the primary purpose of an operating system in computer science?
    - ( ) Simulate natural disasters
    - (x) Manage hardware resources and provide services to applications
    - ( ) Generate random numbers
    - ( ) Control physical robots

2. Which programming language is commonly used for low-level system programming and development of operating systems?
    - ( ) Python
    - ( ) Java
    - (x) C

3. In computer networks, what does the acronym "IP" stand for?
    - ( ) Internet Program
    - (x) Internet Protocol
    - ( ) Integrated Processing

4. What is the role of a router in a computer network?
    - ( ) Manage file storage
    - ( ) Provide electrical power
    - (x) Direct data packets between different networks

5. Which data structure is commonly used for implementing a Last-In-First-Out (LIFO) order of elements?
    - ( ) Queue
    - (x) Stack
    - ( ) Linked List

6. What is the purpose of a database management system (DBMS)?
    - ( ) Play video games
    - ( ) Design user interfaces
    - (x) Manage and organize structured information in databases

7. What does the acronym "SQL" stand for in the context of databases?
    - ( ) Simple Question Language
    - ( ) Structured Query Logic
    - (x) Structured Query Language

8. In computer graphics, what does the term "pixel" refer to?
    - ( ) A unit of sound
    - (x) A small, distinct point in an image
    - ( ) A computer programming language

9. What is the purpose of a firewall in computer security?
    - ( ) Create virtual reality environments
    - ( ) Enhance graphic design
    - (x) Monitor and control incoming and outgoing network traffic

10. Which encryption algorithm is commonly used for securing online communication, such as HTTPS?
    - ( ) Caesar Cipher
    - ( ) RSA
    - (x) AES

# End of Computer Science Engineering Quiz - Thank You.
```